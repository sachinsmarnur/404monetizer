<?php
/*
Plugin Name: IFSC Lookup Plugin
Description: A plugin to lookup Indian bank IFSC codes with searchable dropdowns, address display, error handling, and exportable results.
Version: 1.4
Author: Grok (xAI)
*/

// Enqueue CSS and JavaScript
function ifsc_lookup_enqueue_scripts() {
    wp_enqueue_style('ifsc-lookup-style', plugins_url('/style.css', __FILE__));
    wp_enqueue_style('select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css');
    wp_enqueue_script('jquery');
    wp_enqueue_script('select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js', array('jquery'), null, true);
    
    // Load jsPDF with proper dependency and in footer
    wp_enqueue_script('jspdf', 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js', array(), '2.5.1', true);
    
    // Localize script to ensure proper loading
    wp_add_inline_script('jspdf', 'window.jsPDF = window.jspdf.jsPDF;', 'after');
}
add_action('wp_enqueue_scripts', 'ifsc_lookup_enqueue_scripts');

// Add admin menu for settings
function ifsc_lookup_admin_menu() {
    add_menu_page('IFSC Lookup Settings', 'IFSC Lookup', 'manage_options', 'ifsc-lookup-settings', 'ifsc_lookup_settings_page');
}
add_action('admin_menu', 'ifsc_lookup_admin_menu');

// Settings page
function ifsc_lookup_settings_page() {
    if (!current_user_can('manage_options')) {
        wp_die('You do not have sufficient permissions to access this page.');
    }

    // Handle CSV upload
    if (isset($_POST['upload_csv']) && !empty($_FILES['csv_file']['name'])) {
        $file = $_FILES['csv_file']['tmp_name'];
        $row_count = count(file($file));
        if ($row_count > 10000) {
            echo '<div class="error"><p>Error: CSV file exceeds 10,000 rows (found ' . $row_count . ' rows).</p></div>';
        } else {
            $csv_data = array_map('str_getcsv', file($file));
            $headers = array_shift($csv_data);
            $existing_data = get_option('ifsc_csv_data', []);
            $existing_headers = get_option('ifsc_csv_headers', []);

            if (!empty($existing_headers) && $headers !== $existing_headers) {
                echo '<div class="error"><p>Warning: CSV headers differ from previous uploads. Using first upload’s headers.</p></div>';
            } else {
                update_option('ifsc_csv_headers', $headers);
            }

            foreach ($csv_data as $row) {
                $row_data = array_combine($headers, $row);
                $bank = $row_data['BANK'];
                if (!isset($existing_data[$bank])) {
                    $existing_data[$bank] = [];
                }
                $existing_data[$bank][] = $row_data;
            }
            update_option('ifsc_csv_data', $existing_data);
            echo '<div class="updated"><p>CSV uploaded successfully! Data added for ' . count($csv_data) . ' rows.</p></div>';
        }
    }

    // Handle column mapping
    if (isset($_POST['save_mapping'])) {
        $mapping = array(
            'bank' => sanitize_text_field($_POST['map_bank']),
            'state' => sanitize_text_field($_POST['map_state']),
            'city' => sanitize_text_field($_POST['map_city']),
            'branch' => sanitize_text_field($_POST['map_branch']),
            'ifsc' => sanitize_text_field($_POST['map_ifsc']),
            'swift' => sanitize_text_field($_POST['map_swift']),
            'micr' => sanitize_text_field($_POST['map_micr']),
            'address' => sanitize_text_field($_POST['map_address'])
        );
        update_option('ifsc_column_mapping', $mapping);
        echo '<div class="updated"><p>Column mapping saved successfully!</p></div>';
    }

    // Handle reset data
    if (isset($_POST['reset_data'])) {
        update_option('ifsc_csv_data', []);
        update_option('ifsc_csv_headers', []);
        update_option('ifsc_column_mapping', []);
        echo '<div class="updated"><p>All data reset successfully!</p></div>';
    }

    ?>
    <div class="wrap">
        <h1>IFSC Lookup Settings</h1>
        <form method="post" enctype="multipart/form-data">
            <h2>Upload CSV File</h2>
            <p>Upload a CSV file with bank data (max 10,000 rows per file).</p>
            <input type="file" name="csv_file" accept=".csv" required>
            <input type="submit" name="upload_csv" value="Upload CSV" class="button-primary">
        </form>

        <?php
        $headers = get_option('ifsc_csv_headers', []);
        $mapping = get_option('ifsc_column_mapping', []);
        $data = get_option('ifsc_csv_data', []);
        if (!empty($headers)) {
            ?>
            <form method="post">
                <h2>Map CSV Columns</h2>
                <p>Map the CSV columns to the plugin fields:</p>
                <table class="form-table">
                    <tr>
                        <th>Bank Name</th>
                        <td><select name="map_bank"><?php echo generate_options($headers, $mapping['bank'] ?? ''); ?></select></td>
                    </tr>
                    <tr>
                        <th>State</th>
                        <td><select name="map_state"><?php echo generate_options($headers, $mapping['state'] ?? ''); ?></select></td>
                    </tr>
                    <tr>
                        <th>City/District</th>
                        <td><select name="map_city"><?php echo generate_options($headers, $mapping['city'] ?? ''); ?></select></td>
                    </tr>
                    <tr>
                        <th>Bank Branch</th>
                        <td><select name="map_branch"><?php echo generate_options($headers, $mapping['branch'] ?? ''); ?></select></td>
                    </tr>
                    <tr>
                        <th>IFSC Code</th>
                        <td><select name="map_ifsc"><?php echo generate_options($headers, $mapping['ifsc'] ?? ''); ?></select></td>
                    </tr>
                    <tr>
                        <th>SWIFT Code</th>
                        <td><select name="map_swift"><?php echo generate_options($headers, $mapping['swift'] ?? ''); ?></select></td>
                    </tr>
                    <tr>
                        <th>MICR Code</th>
                        <td><select name="map_micr"><?php echo generate_options($headers, $mapping['micr'] ?? ''); ?></select></td>
                    </tr>
                    <tr>
                        <th>Address</th>
                        <td><select name="map_address"><?php echo generate_options($headers, $mapping['address'] ?? ''); ?></select></td>
                    </tr>
                </table>
                <input type="submit" name="save_mapping" value="Save Mapping" class="button-primary">
            </form>
            <h2>Uploaded Data</h2>
            <p>Currently loaded: <?php echo count($data); ?> banks, <?php echo array_sum(array_map('count', $data)); ?> total rows.</p>
            <form method="post">
                <input type="submit" name="reset_data" value="Reset All Data" class="button-secondary" onclick="return confirm('Are you sure?');">
            </form>
            <?php
        }
        ?>
    </div>
    <?php
}

// Helper function for dropdown options
function generate_options($headers, $selected = '') {
    $options = '<option value="">Select Column</option>';
    foreach ($headers as $header) {
        $is_selected = ($header === $selected) ? ' selected' : '';
        $options .= "<option value='$header'$is_selected>$header</option>";
    }
    return $options;
}

// Shortcode to display the IFSC lookup form
function ifsc_lookup_shortcode() {
    $csv_data = get_option('ifsc_csv_data', []);
    $mapping = get_option('ifsc_column_mapping', []);
    if (empty($csv_data) || empty($mapping)) {
        return '<p>Please upload a CSV file and map the columns in the IFSC Lookup Settings.</p>';
    }

    $bank_data = [];
    $headers = get_option('ifsc_csv_headers', []);
    foreach ($csv_data as $bank => $rows) {
        foreach ($rows as $row) {
            $row_data = is_array($row) ? $row : array_combine($headers, $row);
            $state = $row_data[$mapping['state']];
            $city = $row_data[$mapping['city']];
            $branch = $row_data[$mapping['branch']];

            if (!isset($bank_data[$bank])) $bank_data[$bank] = [];
            if (!isset($bank_data[$bank][$state])) $bank_data[$bank][$state] = [];
            if (!isset($bank_data[$bank][$state][$city])) $bank_data[$bank][$state][$city] = [];

            $bank_data[$bank][$state][$city][] = [
                'branch' => $branch,
                'ifsc' => $row_data[$mapping['ifsc']],
                'swift' => $row_data[$mapping['swift']] ?? '',
                'micr' => $row_data[$mapping['micr']] ?? '',
                'address' => $row_data[$mapping['address']] ?? ''
            ];
        }
    }

    ob_start();
    ?>
    <div id="ifsc-lookup">
        <h2>Find Bank IFSC Code</h2>
        <div class="dropdowns-container"> <!-- Add this wrapper -->
            <select id="bank-name" onchange="filterStates()">
                <option value="">Select Bank Name</option>
                <?php foreach (array_keys($bank_data) as $bank) : ?>
                    <option value="<?php echo esc_attr($bank); ?>"><?php echo esc_html($bank); ?></option>
                <?php endforeach; ?>
            </select>
    
            <select id="state" onchange="filterCities()" disabled>
                <option value="">Select State</option>
            </select>
    
            <select id="city" onchange="filterBranches()" disabled>
                <option value="">Select City/District</option>
            </select>
    
            <select id="branch" onchange="displayDetails()" disabled>
                <option value="">Select Bank Branch</option>
            </select>
        </div>

        <div id="bank-details" style="display:none;">
            <table>
                <tr><th>Bank Name</th><td id="detail-bank"></td></tr>
                <tr><th>Bank Branch Name</th><td id="detail-branch"></td></tr>
                <tr><th>State Name</th><td id="detail-state"></td></tr>
                <tr><th>City/District Name</th><td id="detail-city"></td></tr>
                <tr><th>Bank IFSC Code</th><td id="detail-ifsc"></td></tr>
                <tr><th>Bank SWIFT Code</th><td id="detail-swift"></td></tr>
                <tr><th>Bank MICR Code</th><td id="detail-micr"></td></tr>
                <tr><th>Address</th><td id="detail-address"></td></tr>
            </table>
            <div id="export-buttons" style="margin-top: 15px;">
                <button onclick="copyToClipboard()">Copy Details</button>
                <button onclick="downloadPDF()">Download PDF</button>
            </div>
            <div id="description"></div>
        </div>
    </div>

    <script>
    jQuery(document).ready(function($) {
        $('#bank-name').select2({
            width: '100%',
            placeholder: 'Select Bank Name'
        });
        $('#state').select2({
            width: '100%',
            placeholder: 'Select State'
        });
        $('#city').select2({
            width: '100%',
            placeholder: 'Select City/District'
        });
        $('#branch').select2({
            width: '100%',
            placeholder: 'Select Bank Branch'
        });
    });

    const bankData = <?php echo json_encode($bank_data); ?>;

    function filterStates() {
        const bank = document.getElementById("bank-name").value;
        const stateDropdown = document.getElementById("state");
        stateDropdown.innerHTML = '<option value="">Select State</option>';
        document.getElementById("city").innerHTML = '<option value="">Select City/District</option>';
        document.getElementById("branch").innerHTML = '<option value="">Select Bank Branch</option>';
        document.getElementById("bank-details").style.display = "none";

        if (bank && bankData[bank]) {
            stateDropdown.disabled = false;
            Object.keys(bankData[bank]).forEach(state => {
                const option = document.createElement("option");
                option.value = state;
                option.text = state;
                stateDropdown.appendChild(option);
            });
            jQuery('#state').select2('destroy').select2({ width: '100%', placeholder: 'Select State' });
        } else {
            stateDropdown.disabled = true;
            document.getElementById("city").disabled = true;
            document.getElementById("branch").disabled = true;
            stateDropdown.innerHTML += '<option value="">No states found</option>';
        }
    }

    function filterCities() {
        const bank = document.getElementById("bank-name").value;
        const state = document.getElementById("state").value;
        const cityDropdown = document.getElementById("city");
        cityDropdown.innerHTML = '<option value="">Select City/District</option>';
        document.getElementById("branch").innerHTML = '<option value="">Select Bank Branch</option>';
        document.getElementById("bank-details").style.display = "none";

        if (state && bankData[bank][state]) {
            cityDropdown.disabled = false;
            Object.keys(bankData[bank][state]).forEach(city => {
                const option = document.createElement("option");
                option.value = city;
                option.text = city;
                cityDropdown.appendChild(option);
            });
            jQuery('#city').select2('destroy').select2({ width: '100%', placeholder: 'Select City/District' });
        } else {
            cityDropdown.disabled = true;
            document.getElementById("branch").disabled = true;
            cityDropdown.innerHTML += '<option value="">No cities found</option>';
        }
    }

    function filterBranches() {
        const bank = document.getElementById("bank-name").value;
        const state = document.getElementById("state").value;
        const city = document.getElementById("city").value;
        const branchDropdown = document.getElementById("branch");
        branchDropdown.innerHTML = '<option value="">Select Bank Branch</option>';
        document.getElementById("bank-details").style.display = "none";

        if (city && bankData[bank][state][city]) {
            branchDropdown.disabled = false;
            bankData[bank][state][city].forEach(branch => {
                const option = document.createElement("option");
                option.value = branch.branch;
                option.text = branch.branch;
                branchDropdown.appendChild(option);
            });
            jQuery('#branch').select2('destroy').select2({ width: '100%', placeholder: 'Select Bank Branch' });
        } else {
            branchDropdown.disabled = true;
            branchDropdown.innerHTML += '<option value="">No branches found</option>';
        }
    }

    function displayDetails() {
        const bank = document.getElementById("bank-name").value;
        const state = document.getElementById("state").value;
        const city = document.getElementById("city").value;
        const branch = document.getElementById("branch").value;

        if (branch && bankData[bank][state][city]) {
            const branchData = bankData[bank][state][city].find(b => b.branch === branch);
            document.getElementById("detail-bank").textContent = bank;
            document.getElementById("detail-branch").textContent = branch;
            document.getElementById("detail-state").textContent = state;
            document.getElementById("detail-city").textContent = city;
            document.getElementById("detail-ifsc").textContent = branchData.ifsc;
            document.getElementById("detail-swift").textContent = branchData.swift || 'N/A';
            document.getElementById("detail-micr").textContent = branchData.micr || 'N/A';
            document.getElementById("detail-address").textContent = branchData.address || 'N/A';
            document.getElementById("bank-details").style.display = "block";

            const description = `
                <h1>Find ${bank} IFSC Code for ${branch} Branch</h1>
                <p>If you are looking for the <strong>IFSC Code, MICR Code, SWIFT Code, and other details</strong> of <strong>${bank}'s ${branch} branch</strong>, you’ve come to the right place.</p>
                <section>
                    <h2>Key Details of ${branch} Branch</h2>
                    <ul>
                        <li><strong>Bank Name:</strong> ${bank}</li>
                        <li><strong>Branch Name:</strong> ${branch}</li>
                        <li><strong>IFSC Code:</strong> <strong>${branchData.ifsc}</strong></li>
                        <li><strong>MICR Code:</strong> ${branchData.micr || 'N/A'}</li>
                        <li><strong>SWIFT Code:</strong> ${branchData.swift || 'N/A'}</li>
                        <li><strong>State:</strong> ${state}</li>
                        <li><strong>District:</strong> ${city}</li>
                        <li><strong>Address:</strong> ${branchData.address || 'N/A'}</li>
                    </ul>
                </section>
                <section>
                    <h2>Why is the IFSC Code Important?</h2>
                    <p>The <strong>IFSC</strong> is an <strong>11-digit alphanumeric code</strong> assigned by the RBI to identify bank branches uniquely.</p>
                    <ul>
                        <li><strong>NEFT</strong></li>
                        <li><strong>RTGS</strong></li>
                        <li><strong>IMPS</strong></li>
                    </ul>
                    <p>Always verify the <strong>${bank} ${branch} IFSC Code (${branchData.ifsc})</strong> before transferring.</p>
                </section>
                <section>
                    <h2>How to Use ${bank} IFSC Code?</h2>
                    <ol>
                        <li><strong>NEFT/RTGS/IMPS:</strong> Enter <strong>${branchData.ifsc}</strong> in your banking app.</li>
                        <li><strong>UPI:</strong> May require IFSC for adding accounts.</li>
                        <li><strong>Cheque:</strong> MICR (<strong>${branchData.micr || 'N/A'}</strong>) aids processing.</li>
                    </ol>
                </section>
                <section>
                    <h2>About ${bank}</h2>
                    <p>${bank} is a leading bank in India with a strong presence in <strong>${state}</strong>.</p>
                </section>
                <section class="faq-section">
                    <h2>FAQs</h2>
                    <div class="faq-item">
                        <h3>How can I find ${bank}’s IFSC Code?</h3>
                        <p>Use this tool, your cheque book, or RBI’s website.</p>
                    </div>
                    <div class="faq-item">
                        <h3>Is the IFSC same for all ${bank} branches?</h3>
                        <p>No, each branch has a unique IFSC.</p>
                    </div>
                    <div class="faq-item">
                        <h3>What if I use the wrong IFSC?</h3>
                        <p>The transaction may fail or go to the wrong account.</p>
                    </div>
                </section>
                <p>Contact <strong>${bank} Customer Care</strong> for more help.</p>
            `;
            document.getElementById("description").innerHTML = description;
        }
    }

    // Copy to Clipboard function
    function copyToClipboard() {
        try {
            const bank = document.getElementById("detail-bank").textContent;
            const branch = document.getElementById("detail-branch").textContent;
            
            if (!bank || !branch) {
                alert('Please select a bank branch first.');
                return;
            }
    
            // Create the text to copy
            let textToCopy = `Bank Details:\n`;
            textToCopy += `Bank Name: ${bank}\n`;
            textToCopy += `Branch: ${branch}\n`;
            textToCopy += `IFSC Code: ${document.getElementById("detail-ifsc").textContent}\n`;
            textToCopy += `Address: ${document.getElementById("detail-address").textContent}\n`;
            
            // Modern clipboard API with fallback
            if (navigator.clipboard) {
                navigator.clipboard.writeText(textToCopy)
                    .then(() => {
                        alert('Bank details copied to clipboard!');
                    })
                    .catch(err => {
                        throw new Error('Clipboard API failed, using fallback');
                    });
            } else {
                // Fallback for older browsers
                const textarea = document.createElement('textarea');
                textarea.value = textToCopy;
                textarea.style.position = 'fixed';
                document.body.appendChild(textarea);
                textarea.select();
                
                const success = document.execCommand('copy');
                document.body.removeChild(textarea);
                
                if (success) {
                    alert('Bank details copied to clipboard!');
                } else {
                    throw new Error('Copy failed');
                }
            }
        } catch (error) {
            console.error('Copy failed:', error);
            alert('Failed to copy. Please manually select and copy the text.');
        }
    }
    
    // Download as PDF - Enhanced version
    function downloadPDF() {
        try {
            const bank = document.getElementById("detail-bank").textContent;
            const branch = document.getElementById("detail-branch").textContent;
            
            if (!bank || !branch) {
                alert('Please select a bank branch first.');
                return;
            }
    
            // Check if jsPDF is available
            if (typeof jsPDF === 'undefined') {
                alert('PDF library not loaded. Please refresh the page and try again.');
                console.error('jsPDF not loaded');
                return;
            }
    
            // Create PDF
            const doc = new jsPDF();
            
            // Add title
            doc.setFontSize(18);
            doc.setTextColor(40, 40, 40);
            doc.text(`${bank} - ${branch} Branch Details`, 10, 15);
            
            // Add details
            doc.setFontSize(12);
            let yPosition = 30;
            
            const details = [
                `Bank Name: ${bank}`,
                `Branch Name: ${branch}`,
                `State: ${document.getElementById("detail-state").textContent}`,
                `City/District: ${document.getElementById("detail-city").textContent}`,
                `IFSC Code: ${document.getElementById("detail-ifsc").textContent}`,
                `SWIFT Code: ${document.getElementById("detail-swift").textContent}`,
                `MICR Code: ${document.getElementById("detail-micr").textContent}`,
                `Address: ${document.getElementById("detail-address").textContent}`
            ];
            
            details.forEach(detail => {
                doc.text(detail, 10, yPosition);
                yPosition += 8;
            });
            
            // Save the PDF
            doc.save(`${bank.replace(/[^a-z0-9]/gi, '_')}_${branch.replace(/[^a-z0-9]/gi, '_')}_details.pdf`);
            
        } catch (error) {
            console.error('PDF generation error:', error);
            alert('Failed to generate PDF. Please try again or contact support.');
        }
    }
    </script>
    <?php
    return ob_get_clean();
}
add_shortcode('ifsc_lookup', 'ifsc_lookup_shortcode');
?>